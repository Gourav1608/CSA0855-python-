def check_mirror():
    # Get input from user
    user_input = input("Enter the number: ")
    
    # Reverse the input
    reversed_input = user_input[::-1]
    
    # Print the mirror image
    print(f"Mirror image: {reversed_input}")
    
    # Check if it is a mirror number
    if user_input == reversed_input:
        print("The number is a mirror number.")
    else:
        print("The number is not a mirror number.")

# Test cases
check_mirror()
