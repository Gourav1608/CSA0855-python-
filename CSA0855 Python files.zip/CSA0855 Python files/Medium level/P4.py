def climb_stairs(n):
    if n <= 2:
        return n

    # Initialize variables to store the number of ways for the last two steps
    first, second = 1, 2

    # Calculate the number of ways for steps 3 to n
    for _ in range(3, n + 1):
        current = first + second
        first = second
        second = current

    return second

# Test cases
test_cases = [2, 3, 4, 1, 5]

# Display results
for i, n in enumerate(test_cases, start=1):
    print(f"Test Case {i}: Input = {n}, Output = {climb_stairs(n)}")
