def add_binary(a, b):
    # Initialize result and carry
    result = []
    carry = 0

    # Make the strings equal length by padding with '0'
    max_len = max(len(a), len(b))
    a = a.zfill(max_len)
    b = b.zfill(max_len)

    # Traverse both strings from right to left
    for i in range(max_len - 1, -1, -1):
        bit_a = int(a[i])
        bit_b = int(b[i])

        # Calculate the sum of bits and carry
        total = bit_a + bit_b + carry
        carry = total // 2  # Carry is 1 if total is 2 or 3
        result.append(str(total % 2))  # Append the remainder to result

    # If there's a carry left, append it
    if carry:
        result.append('1')

    # Reverse the result and join to form the binary string
    return ''.join(reversed(result))

# Test cases
test_cases = [
    ("11", "1"),
    ("1010", "1011"),
    ("1111", "1010"),
    ("101101", "1100"),
    ("1011", "1111")
]

# Display results
for i, (a, b) in enumerate(test_cases, start=1):
    print(f"Test Case {i}: a = {a}, b = {b}, Output = {add_binary(a, b)}")
