import math

def num_squares(n):
    # Initialize DP array with infinity
    dp = [float('inf')] * (n + 1)
    dp[0] = 0  # Base case: no squares needed to sum to 0

    # Fill dp array
    for i in range(1, n + 1):
        for j in range(1, int(math.sqrt(i)) + 1):
            dp[i] = min(dp[i], dp[i - j * j] + 1)
    
    return dp[n]

# Test cases
test_cases = [12, 13, 1, 4, 3]

# Display results
for i, test in enumerate(test_cases, start=1):
    print(f"Test Case {i}: Input = {test}, Output = {num_squares(test)}")
