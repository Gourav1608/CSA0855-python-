def print_pattern(start, lines):
    """
    Prints a pattern starting from a given float and up to the specified lines.
    """
    if lines <= 0:
        print("Invalid number of lines. Enter a positive integer.")
        return

    current = start
    for i in range(1, lines + 1):
        print(" ".join(f"{current + j / 10:.1f}" for j in range(i)))
        current += i / 10

# Test Cases
print_pattern(1.4, 3)
print_pattern(5.6, 4)
print_pattern(0.8, -1)  # Invalid case
print_pattern(1.9, 0)   # Invalid case
print_pattern(3.4, 5)
