def is_perfect_number(n):
    """
    Checks if a number is a perfect number.
    """
    return sum(i for i in range(1, n) if n % i == 0) == n

def perfect_numbers_and_factors(n, m):
    """
    Prints the first n perfect numbers and their first m factors.
    """
    if n <= 0 or m <= 0:
        print("Invalid input. Both N and M must be positive integers.")
        return

    count = 0
    num = 2
    while count < n:
        if is_perfect_number(num):
            factors = [i for i in range(1, num + 1) if num % i == 0]
            print(f"First {m} factors of {num} are: {', '.join(map(str, factors[:m]))}")
            count += 1
        num += 1

# Test Cases
perfect_numbers_and_factors(3, 4)  # 6, 28, 496
perfect_numbers_and_factors(0, 3)  # Invalid case
perfect_numbers_and_factors(4, 4)
perfect_numbers_and_factors(12, 3)
perfect_numbers_and_factors(-5, 3)  # Invalid case
perfect_numbers_and_factors(0.2, -4)  # Invalid case
