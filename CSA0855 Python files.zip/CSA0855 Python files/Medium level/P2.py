def are_isomorphic(s, t):
    if len(s) != len(t):
        return False

    # Dictionaries to map characters from s to t and vice versa
    s_to_t = {}
    t_to_s = {}

    for char_s, char_t in zip(s, t):
        # Check and update mappings for both directions
        if (char_s in s_to_t and s_to_t[char_s] != char_t) or (char_t in t_to_s and t_to_s[char_t] != char_s):
            return False
        s_to_t[char_s] = char_t
        t_to_s[char_t] = char_s

    return True

# Test cases
test_cases = [
    ("egg", "add"),
    ("foo", "bar"),
    ("paper", "title"),
    ("fry", "sky"),
    ("apples", "apple"),
]

# Display results
for s, t in test_cases:
    print(f"s = \"{s}\", t = \"{t}\": {are_isomorphic(s, t)}")
