def matches(s1, s2):
    """
    Returns the count of matches between two strings.
    A match is where characters at the same index are the same.
    """
    return sum(1 for a, b in zip(s1, s2) if a == b)

# Test Cases
print(matches("what", "watch"))  # Output: 1
print(matches("ran", "van"))     # Output: 2
print(matches("rain", "turn"))   # Output: 1
print(matches("python", "py"))   # Output: 2
print(matches("man", "women"))   # Output: 1

