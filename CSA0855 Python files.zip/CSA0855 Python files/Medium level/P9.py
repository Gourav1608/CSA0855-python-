def letter_combinations(digits):
    # Mapping of digits to corresponding letters
    digit_to_char = {
        '2': "abc", '3': "def", '4': "ghi", '5': "jkl",
        '6': "mno", '7': "pqrs", '8': "tuv", '9': "wxyz"
    }

    # If the input is empty, return an empty list
    if not digits:
        return []

    # Recursive helper function
    def backtrack(index, path):
        # If the path length equals the input digits length, add to results
        if index == len(digits):
            combinations.append("".join(path))
            return

        # Iterate over the possible characters for the current digit
        for char in digit_to_char[digits[index]]:
            path.append(char)
            backtrack(index + 1, path)
            path.pop()  # Backtrack

    # Initialize the result list
    combinations = []
    backtrack(0, [])
    return combinations

# Test cases
test_cases = [
    "23",
    "",
    "2",
    "9",
    "87"
]

# Display results
for i, digits in enumerate(test_cases, start=1):
    print(f"Test Case {i}: Input = {digits}, Output = {letter_combinations(digits)}")
