def pascal_triangle(num_rows, row_num):
    # Handle invalid input
    if num_rows <= 0 or row_num <= 0 or row_num > num_rows:
        print("Invalid input. Number of rows and row number must be positive, and the row number must be within range.")
        return
    
    # Initialize Pascal's Triangle
    triangle = [[1]]  # First row is always [1]

    for i in range(1, num_rows):
        prev_row = triangle[-1]
        new_row = [1]  # Start with 1
        for j in range(1, len(prev_row)):
            new_row.append(prev_row[j-1] + prev_row[j])  # Sum of two adjacent numbers
        new_row.append(1)  # End with 1
        triangle.append(new_row)
    
    # Print Pascal's Triangle
    print("\nPascal's Triangle:")
    for row in triangle:
        print(" ".join(map(str, row)))
    
    # Extract the required row
    target_row = triangle[row_num - 1]
    row_sum = sum(target_row)
    print(f"\nSum of elements in {row_num}th row: {row_sum}")

# Input from user
try:
    num_rows = int(input("Enter the number of rows: "))
    row_num = int(input("Enter the row number: "))
    pascal_triangle(num_rows, row_num)
except ValueError:
    print("Please enter valid integers for number of rows and row number.")

