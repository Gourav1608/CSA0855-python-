def find_mth_max_nth_min(lst, M, N):
    # Sort the list
    lst.sort()
    
    # Mth maximum (last Mth element from the end)
    mth_max = lst[-M] if M > 0 else None
    
    # Nth minimum (Nth element from the beginning)
    nth_min = lst[N-1] if N <= len(lst) else None

    # If either mth_max or nth_min is None, return None
    if mth_max is None or nth_min is None:
        return None, None, None, None

    # Calculate sum and difference
    sum_value = mth_max + nth_min
    diff_value = mth_max - nth_min

    return mth_max, nth_min, sum_value, diff_value

# Test cases
test_cases = [
    ([16, 16, 16, 16, 16], 0, 1),
    ([0, 0, 0, 0], 1, 2),
    ([-12, -78, -35, -42, -85], 3, 3),
    ([15, 19, 34, 56, 12], 6, 3),
    ([85, 45, 65, 75, 95], 5, 7)
]

# Display results
for i, (lst, M, N) in enumerate(test_cases, start=1):
    mth_max, nth_min, sum_value, diff_value = find_mth_max_nth_min(lst, M, N)
    print(f"Test Case {i}: Input = {lst}, M = {M}, N = {N}")
    print(f"1st Maximum Number = {mth_max}")
    print(f"{N}th Minimum Number = {nth_min}")
    print(f"Sum = {sum_value}")
    print(f"Difference = {diff_value}\n")
