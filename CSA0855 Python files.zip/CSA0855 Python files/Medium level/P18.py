def factorial_and_factors(n):
    """
    Returns the factorial and the number of factors of n.
    """
    if n < 0:
        return "Invalid input. Enter a non-negative integer."
    # Calculate factorial
    factorial = 1
    for i in range(1, n + 1):
        factorial *= i
    
    # Calculate factors
    factors = [i for i in range(1, n + 1) if n % i == 0]
    return factorial, len(factors)

# Test Cases
print(factorial_and_factors(6))    # Output: (720, 4)
print(factorial_and_factors(0))    # Output: (1, 0)
print(factorial_and_factors(-5))   # Output: Invalid input
print(factorial_and_factors(1))    # Output: (1, 1)
print(factorial_and_factors(20))   # Output: (2432902008176640000, 6)
