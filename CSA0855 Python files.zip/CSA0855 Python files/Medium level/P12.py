def count_characters():
    uppercase_count = 0
    lowercase_count = 0
    number_count = 0

    while True#The loop runs indefinitely, allowing the user to keep entering characters until a specific condition (termination character *) is met.
        char = input("Enter any character: ")#The user is prompted to input a character. The input is stored in the variable char.

        if char == '*':#If the user enters an asterisk (*), the loop is exited using the break statement.
            break

        if char.isupper():
            uppercase_count += 1
        elif char.islower():
            lowercase_count += 1
        elif char.isdigit():
            number_count += 1
try:            

    print(f"Total count of upper case: {uppercase_count}")
    print(f"Total count of lower case: {lowercase_count}")
    print(f"Total count of numbers: {number_count}")
except ValueError:
    print("invalid input , pleases enter valid integer or string ")


