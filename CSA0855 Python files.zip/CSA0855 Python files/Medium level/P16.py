def calculate_shipping(items):
    """
    Calculate the shipping charge based on the number of items.
    
    :param items: int, the number of items
    :return: float, the shipping charge or a message for invalid input
    """
    if items <= 0:
        return "Invalid number of items. Please enter a positive integer."
    elif items == 1:
        return 750.00
    else:
        return 750.00 + (items - 1) * 200.00

# Get input from the user
try:
    num_items = int(input("Enter the number of items purchased: "))
    result = calculate_shipping(num_items)
    if isinstance(result, str):
        print(result)  # Handle invalid input
    else:
        print(f"Shipping charge: {result:.2f}")  # Valid input
except ValueError:
    print("Invalid input. Please enter an integer.")

