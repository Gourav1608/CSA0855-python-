# Constants
PRICE_PER_LOAF = 185.00
DISCOUNT_PERCENTAGE = 60  # Percent

# Input from user
fresh_loaves = int(input("Enter the number of fresh loaves purchased: "))
day_old_loaves = int(input("Enter the number of day old loaves purchased: "))

# Validation
if fresh_loaves < 0 or day_old_loaves < 0:
    print("Invalid input! The number of loaves cannot be negative.")
else:
    # Calculations
    regular_price = PRICE_PER_LOAF
    fresh_total = fresh_loaves * PRICE_PER_LOAF
    day_old_discounted_price = PRICE_PER_LOAF * (1 - DISCOUNT_PERCENTAGE / 100)
    day_old_total = day_old_loaves * day_old_discounted_price
    total_price = fresh_total + day_old_total

    # Output with formatting
    print(f"\n{'Regular price:':<25} Rs.{regular_price:7.2f}")
    print(f"{'Amount of new loaves:':<25} Rs.{fresh_total:7.2f}")
    print(f"{'Amount of day old loaves:':<25} Rs.{day_old_total:7.2f}")
    print(f"{'Total amount:':<25} Rs.{total_price:7.2f}")
