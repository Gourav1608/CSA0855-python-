def calculate(s):
    # Remove spaces from the string
    s = s.replace(" ", "")
    stack = []
    num = 0
    operator = '+'

    for i, char in enumerate(s):
        if char.isdigit():
            num = num * 10 + int(char)

        # Process when we encounter an operator or reach the end of the string
        if not char.isdigit() or i == len(s) - 1:
            if operator == '+':
                stack.append(num)
            elif operator == '-':
                stack.append(-num)
            elif operator == '*':
                stack.append(stack.pop() * num)
            elif operator == '/':
                # Integer division truncates toward zero
                stack.append(int(stack.pop() / num))

            operator = char  # Update the operator
            num = 0  # Reset num for the next number

    return sum(stack)

# Test cases
test_cases = [
    "3+2*2",
    " 3/2 ",
    " 3+5 / 2 ",
    "-1+5",
    "2+3+5"
]

# Display results
for i, expression in enumerate(test_cases, start=1):
    print(f"Test Case {i}: Input = {expression}, Output = {calculate(expression)}")
