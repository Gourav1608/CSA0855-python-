def merge_sorted_lists(list1, list2):
 
    return sorted(list1 + list2)
def main():
    test_cases = [
        ([1, 2, 4], [1, 3, 4]),
        ([], []),
        ([], [0]),
        ([], [1, 2, 3, 4, 5]),
        ([0, 1, 9], [3, 4, 5])
    ]

    for idx, (list1, list2) in enumerate(test_cases, start=1):
        result = merge_sorted_lists(list1, list2)
        print(f"Test case {idx}: Input: list1={list1}, list2={list2}\nOutput: {result}\n")

if __name__ == "__main__":
    main()
