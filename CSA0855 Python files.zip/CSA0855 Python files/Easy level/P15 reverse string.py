def reverse_string(string):
    reversed_str = ""
    for char in string:
        reversed_str = char + reversed_str
    return reversed_str

# Test cases
test_cases = ["TEMPLE", "SIGN UP", "AT-LEAST", "1245", "!@#$%", "145*999=144855"]

# Process and print results
for case in test_cases:
    print(f"Original String: {case}")
    print(f"Reversed String: {reverse_string(case)}")
    print("-" * 30)
