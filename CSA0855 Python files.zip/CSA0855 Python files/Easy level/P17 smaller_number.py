def smaller_numbers_than_current(nums):
    # List to store the result
    result = []
    # Loop through each element in the list
    for i in range(len(nums)):
        count = 0
        # Compare it with every other element
        for j in range(len(nums)):
            if i != j and nums[j] < nums[i]:
                count += 1
        result.append(count)
    return result

# Test cases
test_cases = [
    [8, 1, 2, 2, 3],
    [6, 5, 4, 8],
    [7, 7, 7, 7],
    [1, 2, 3, 5, 5, 6],
    [0, 0, 0, 0],
]

# Process and print results for each test case
for nums in test_cases:
    print(f"Input: nums = {nums}")
    print(f"Output: {smaller_numbers_than_current(nums)}")
    print("-" * 30)
