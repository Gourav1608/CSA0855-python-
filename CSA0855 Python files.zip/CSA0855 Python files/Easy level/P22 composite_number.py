def is_composite(num):
    if num <= 1:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return True
    return False

def print_composite_numbers(a, b):
    # Ensure a is less than or equal to b
    a, b = min(a, b), max(a, b)

    # Find composite numbers in the range
    composite_numbers = [num for num in range(a, b + 1) if is_composite(num)]

    # Print result
    if composite_numbers:
        print(", ".join(map(str, composite_numbers)))
    else:
        print("No composite numbers found in the range.")

# Test cases
print("Test Case 1:")
print_composite_numbers(12, 19)

print("Test Case 2:")
print_composite_numbers(11, 11)

print("Test Case 3:")
print_composite_numbers(20, 10)

print("Test Case 4:")
print_composite_numbers(0, 0)

print("Test Case 5:")
print_composite_numbers(-5, 5)

print("Test Case 6:")
print_composite_numbers(7, -12)
