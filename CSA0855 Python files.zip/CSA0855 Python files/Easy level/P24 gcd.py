import math
from functools import reduce

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def lcm(a, b):
    return a * b // gcd(a, b)

def find_gcd(numbers):
    return reduce(gcd, numbers)

def find_lcm(numbers):
    return reduce(lcm, numbers)

# Main function to get inputs and calculate GCD and LCM
def main():
    try:
        n = int(input("Enter the N value: "))
        if n <= 0:
            print("N should be a positive integer.")
            return
        
        numbers = []
        for i in range(n):
            number = int(input(f"Enter Number {i+1}: "))
            numbers.append(number)
        
        gcd_value = find_gcd(numbers)
        lcm_value = find_lcm(numbers)
        
        print(f"LCM = {lcm_value}")
        print(f"GCD = {gcd_value}")
    except ValueError:
        print("Invalid input. Please enter integers only.")

# Test cases
test_cases = [
    [12, 25, 30],
    [52, 25, 63],
    [17, 19, 11],
    [30, 45],
]

for case in test_cases:
    print(f"\nTest case: {case}")
    try:
        gcd_value = find_gcd(case)
        lcm_value = find_lcm(case)
        print(f"LCM = {lcm_value}")
        print(f"GCD = {gcd_value}")
    except Exception as e:
        print(f"Error: {str(e)}")

# Run the main function
if __name__ == "__main__":
    main()
