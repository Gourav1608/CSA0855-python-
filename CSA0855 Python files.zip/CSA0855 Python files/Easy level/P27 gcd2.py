def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def count_common_divisors(a, b):
    # Calculate the GCD of the two numbers
    gcd_value = gcd(a, b)
    count = 0

    # Count the number of divisors of the GCD
    for i in range(1, abs(gcd_value) + 1):
        if gcd_value % i == 0:
            count += 1
    
    return count

# Test cases
test_cases = [
    (4, 12),
    (4, 8),
    (-10, 0),
    (12, 34),
    (16, 17)
]

for a, b in test_cases:
    common_divisors_count = count_common_divisors(a, b)
    print(f"Number of integers that divide both {a} and {b}: {common_divisors_count}")
