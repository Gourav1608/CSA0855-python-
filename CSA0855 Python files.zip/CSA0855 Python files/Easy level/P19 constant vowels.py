def separate_consonants_vowels(word):
    vowels = "aeiouAEIOU"
    consonants = []
    vowel_list = []

    for char in word:
        if char.isalpha():  # Check if the character is a letter
            if char in vowels:
                vowel_list.append(char)
            else:
                consonants.append(char)

    return consonants, vowel_list

# Test cases
test_cases = ["Engineering", "TRY", "MEDIAN", "ONE", "KNOWLEDGE", "EDUCATION"]

for i, word in enumerate(test_cases, start=1):
    consonants, vowels = separate_consonants_vowels(word)
    print(f"Test Case {i}:")
    print(f"Given Word: {word}")
    print(f"Consonants: {' '.join(consonants)}")
    print(f"Vowels: {' '.join(vowels)}\n")
