def reverse_number():
    user_input = input("Enter a number: ")

    # Filter out non-numeric characters
    filtered_input = ''.join(filter(lambda x: x.isdigit() or x == '-', user_input))

    if not filtered_input or (filtered_input == '-' and len(filtered_input) == 1):
        print("Invalid input. Please enter a valid number.")
        return

    # Handle negative numbers
    if filtered_input[0] == '-':
        reversed_number = '-' + filtered_input[:0:-1]
    else:
        reversed_number = filtered_input[::-1]

    print(f"Reversed Number: {reversed_number}")

# Test cases
def test_reverse_number():
    test_inputs = ["14567", "-45721", "000", "AD1947", "!@#$%", "145*999=144855"]
    print("Test Cases:")
    for i, test_input in enumerate(test_inputs, start=1):
        print(f"Test Case {i}: Input: {test_input}")
        filtered_input = ''.join(filter(lambda x: x.isdigit() or x == '-', test_input))
        if not filtered_input or (filtered_input == '-' and len(filtered_input) == 1):
            print("Invalid input. Please enter a valid number.")
            continue

        if filtered_input[0] == '-':
            reversed_number = '-' + filtered_input[:0:-1]
        else:
            reversed_number = filtered_input[::-1]

        print(f"Reversed Number: {reversed_number}\n")

# Uncomment the line below to run interactively
# reverse_number()

# Run test cases
test_reverse_number()
