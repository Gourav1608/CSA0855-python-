n=6
m=4
add = n+m
print("Addition of",n,"and",m,"is",add)
sub = n-m
print("Subtraction of ",n,"and",m,"is",sub)
mul = n*m
print("Multiplication of",n,"and",m,"is",mul)
Fdiv = n//m
print("Floor divison",n,"and",m,"is",Fdiv)
