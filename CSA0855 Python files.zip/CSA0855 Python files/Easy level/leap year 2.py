def is_leap_year(year):
    # Handle invalid input (negative or non-integer years)
    if not isinstance(year, int) or year <= 0:
        return "Invalid year"

    # Leap year rules
    if year % 400 == 0:
        return "Leap Year"
    elif year % 100 == 0:
        return "Non Leap Year"
    elif year % 4 == 0:
        return "Leap Year"
    else:
        return "Non Leap Year"

# Reading user input
try:
    year = int(input("Enter Year: "))
    print(f"Given year is {is_leap_year(year)}")
except ValueError:
    print("Invalid input. Please enter a valid integer year.")
