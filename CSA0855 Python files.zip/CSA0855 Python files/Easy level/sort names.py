def sort_names():
     print("Enter names one by one and type 'done' when finished:")
     names = []
 
     while True:
         name = input().strip()
         if name.lower() == 'done':
             break
         names.append(name)
 
     if not names:
         print("No names were entered.")
         return 
     order = input("Order (A for Ascending / D for Descending): ").strip().upper()
 
     if order == 'A':
         sorted_names = sorted(names, key=str.casefold)
     elif order == 'D':
         sorted_names = sorted(names, key=str.casefold, reverse=True)
     else:
        print("Invalid order choice. Please enter 'A' or 'D'.")
        return
 
     print("\nSorted names:")
     for name in sorted_names:
         print(name) 
    # Test the program
     if __name__ == "__main__":
         sort_names()
