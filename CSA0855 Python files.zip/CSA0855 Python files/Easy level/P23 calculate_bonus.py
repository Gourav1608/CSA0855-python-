def calculate_bonus(salary, grade):
    if grade == 'A':
        bonus = salary * 0.05
    elif grade == 'B':
        bonus = salary * 0.10
    else:
        bonus = 0  # No bonus for other grades
    
    if salary < 10000:
        bonus += salary * 0.02  # Extra 2% bonus for salaries less than $10,000
    
    return bonus

def main():
    try:
        grade = input("Enter the grade of the employee: ").strip().upper()
        salary = float(input("Enter the employee salary: ").strip())
        
        if salary < 0:
            print("Salary cannot be negative.")
            return
        
        bonus = calculate_bonus(salary, grade)
        total_salary = salary + bonus
        
        print(f"Salary={salary}")
        print(f"Bonus={bonus}")
        print(f"Total to be paid={total_salary}")
    except ValueError:
        print("Invalid input. Please enter numeric values for salary and valid grades (A, B, C).")

# Run the main function
main()

# Test cases (you can use similar main() function or hardcode the values for testing)
test_cases = [
    ('A', 8000),
    ('C', 60000),
    ('B', 0),
    ('38000', 'A'),  # This will throw an error due to invalid grade input
    ('B', -8000)  # This will handle the negative salary case
]

for grade, salary in test_cases:
    try:
        print(f"\nTest case - Grade: {grade}, Salary: {salary}")
        if isinstance(salary, str):
            salary = float(salary)
        
        bonus = calculate_bonus(salary, grade)
        total_salary = salary + bonus
        print(f"Salary={salary}")
        print(f"Bonus={bonus}")
        print(f"Total to be paid={total_salary}")
    except ValueError:
        print("Invalid input in test case.")
    except Exception as e:
        print(f"Error: {str(e)}")

