def length_of_last_word(s):
    # Strip trailing spaces and split the string by spaces
    words = s.strip().split()
    if not words:
        return 0  # If no words exist, return 0
    return len(words[-1])

# Test cases
def test_length_of_last_word():
    test_cases = [
        "Hello World",
        " fly me to the moon ",
        "luffy is still joyboy",
        "123",
        " 45&29 8*6^4"
    ]

    for i, test_input in enumerate(test_cases, start=1):
        print(f"Test Case {i}: Input: '{test_input}'")
        result = length_of_last_word(test_input)
        print(f"Output: {result}\n")

# Uncomment the line below to test interactively
# length_of_last_word(input("Enter a string: "))

# Run test cases
test_length_of_last_word()
