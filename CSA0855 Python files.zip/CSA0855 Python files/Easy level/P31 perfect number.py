def is_perfect_number(num):
    if num < 1:
        return False
    
    # Calculate the sum of divisors
    sum_of_divisors = sum(i for i in range(1, num) if num % i == 0)
    
    return sum_of_divisors == num

# Sample input
try:
    number_input = input("Given Number: ")
    
    # Convert input to an integer
    number = int(number_input)

    if is_perfect_number(number):
        print("It's a Perfect Number")
    else:
        print("It's not a Perfect Number")

except ValueError:
    print("Invalid input. Please enter a valid integer.")
