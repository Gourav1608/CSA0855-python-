def are_isomorphic(s, t):
    if len(s) != len(t):
        return False

    # Create two dictionaries to store the mapping
    s_to_t = {}
    t_to_s = {}

    for char_s, char_t in zip(s, t):
        # Check the mapping from s to t
        if char_s in s_to_t:
            if s_to_t[char_s] != char_t:
                return False
        else:
            s_to_t[char_s] = char_t

        # Check the mapping from t to s
        if char_t in t_to_s:
            if t_to_s[char_t] != char_s:
                return False
        else:
            t_to_s[char_t] = char_s

    return True

# Test cases
test_cases = [
    ("egg", "add"),      # Output: true
    ("foo", "bar"),      # Output: false
    ("paper", "title"),  # Output: true
    ("fry", "sky"),      # Output: true
    ("apples", "apple")  # Output: false
]

# Running the test cases
for s, t in test_cases:
    result = are_isomorphic(s, t)
    print(f"Input: s = \"{s}\", t = \"{t}\" => Output: {result}")
