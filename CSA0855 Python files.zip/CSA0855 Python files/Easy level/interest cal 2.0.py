def Calculate_simple_interest(pricipal, years, is_senior_citizen):
    if is_senior_citizen.lower()== 'y':
        rate_of_interest = 15
    else:
        rate_of_interest = 12

    simple_interest = (principal * rate_of_interest * years)/100
    return simple_interest

principal = float(input("Enter the principal amount: "))
years = float(input("Enter the no of years: "))
is_senior_citizen = input("is customer senior citizen (y/n): ")

interest = Calculate_simple_interest(principal, years, is_senior_citizen)

print(f"interest : {interest}")
