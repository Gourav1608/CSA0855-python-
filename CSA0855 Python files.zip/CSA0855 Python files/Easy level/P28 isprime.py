def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def count_primes_and_composites(numbers):
    primes = 0
    composites = 0
    
    for number in numbers:
        if isinstance(number, int) and number > 1:
            if is_prime(number):
                primes += 1
            else:
                composites += 1
        # Ignore non-integer and non-positive numbers for prime and composite classification

    return primes, composites

def main():
    try:
        numbers = input("Enter the numbers separated by commas: ").split(',')
        numbers = [int(num.strip()) for num in numbers]
        
        primes, composites = count_primes_and_composites(numbers)
        
        print(f"Composite numbers: {composites}")
        print(f"Prime numbers: {primes}")
    except ValueError:
        print("Invalid input. Please enter integers separated by commas.")

# Run the main function
main()

# Test cases
test_cases = [
    [33, 41, 52, 61, 73, 90],
    ["TEN", "FIFTY", "SIXTY-ONE", "SEVENTY-SEVEN", "NINE"],  # Invalid inputs, will be ignored
    [45, 87, 0.9, 5.0, 2.3, 0.4],  # Mixed valid and invalid inputs
    [-54, -76, -97, -23, -33, -98],  # Negative numbers
    [45, 73, 0, 50, 67, 44]
]

for case in test_cases:
    try:
        print(f"\nTest case: {case}")
        numbers = [int(num) if isinstance(num, str) and num.isdigit() else num for num in case]
        primes, composites = count_primes_and_composites(numbers)
        print(f"Composite numbers: {composites}")
        print(f"Prime numbers: {primes}")
    except ValueError:
        print("Invalid input in test case.")
    except Exception as e:
        print(f"Error: {str(e)}")
