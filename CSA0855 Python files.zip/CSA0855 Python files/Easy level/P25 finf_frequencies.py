def find_frequencies(lst):
    frequency_dict = {}
    for item in lst:
        if item in frequency_dict:
            frequency_dict[item] += 1
        else:
            frequency_dict[item] = 1
    return frequency_dict

def print_frequencies(freq_dict):
    print("Element | Frequency")
    print("--------------------------")
    for key, value in freq_dict.items():
        print(f"{key}\t| {value}")

# Sample Input
sample_list = [1, 2, 8, 3, 2, 2, 2, 5, 1]

# Find frequencies
frequencies = find_frequencies(sample_list)

# Print frequencies
print_frequencies(frequencies)

# Test Cases
test_cases = [
    [9, 10, 8, 3, 4, 5, 9, 8],
    [1, 2, 4, 2, 5, 2, 5, 1],
    [91, 10, 81, 33, 44, 55, 91, 81, 44],
    [0.1, 0.2, 0.1, 0.3, 0.4, 0.2, 0.1],
    [-1, -2, 4, -2, 5, 2, 5, -1]
]

for case in test_cases:
    print("\nTest case:", case)
    frequencies = find_frequencies(case)
    print_frequencies(frequencies)
