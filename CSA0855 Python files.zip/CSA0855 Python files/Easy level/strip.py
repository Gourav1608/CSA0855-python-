text = " gourav_yadav__  "
result = text.strip()
print(result)
