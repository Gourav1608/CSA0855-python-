def print_pattern(character, max_count):
    if max_count <= 0:
        print("Max Number of times printed should be greater than 0.")
        return
    
    for i in range(1, max_count + 1):
        print(character * i)

# Sample input
try:
    char_input = input("Enter the Character to be printed: ")
    max_count_input = input("Max Number of times printed: ")

    # Convert max_count_input to an integer
    max_count = int(max_count_input)

    print_pattern(char_input, max_count)

except ValueError:
    print("Invalid input. Please enter a valid integer for the max count.")
