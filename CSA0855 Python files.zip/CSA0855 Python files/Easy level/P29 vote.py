def check_voting_eligibility(age):
    # Define the minimum age for voting
    voting_age = 18
    
    # Check if the age is a valid number
    if isinstance(age, (int, float)) and age >= 0:
        if age >= voting_age:
            print("You are eligible to vote.")
        else:
            years_left = voting_age - age
            print(f"You are allowed to vote after {years_left} years.")
    else:
        print("Invalid age input. Please enter a non-negative number.")

# Sample input
try:
    age_input = input("Enter your age: ")
    
    # Convert input to appropriate type
    if age_input.isdigit():
        age = int(age_input)
    else:
        # Try to convert to float if it's not a digit
        try:
            age = float(age_input)
        except ValueError:
            age = None

    check_voting_eligibility(age)

except Exception as e:
    print(f"An error occurred: {e}")
