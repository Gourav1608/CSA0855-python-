def calculate_student_users(total_users, staff_users):
    if total_users < 0 or staff_users < 0 or staff_users > total_users:
        return "Invalid input. Please ensure total users >= 0, staff users >= 0, and staff users <= total users."
    
    # Calculate the number of non-teaching staff (1 for every 3 teaching staff users)
    non_teaching_staff = staff_users // 3
    
    # Calculate total staff (teaching + non-teaching)
    total_staff = staff_users + non_teaching_staff
    
    # Calculate the number of student users
    student_users = total_users - total_staff
    
    if student_users < 0:
        return "Invalid distribution: staff exceeds total users."
    
    return student_users

# Test cases
test_cases = [
    (856, 126),
    (0, 0),
    (-143, 50),
    (1026, 1026),
    (450, 540),
    (600, 450)
]

# Process and print results for each test case
for total, staff in test_cases:
    result = calculate_student_users(total, staff)
    print(f"Total Users: {total}, Staff Users: {staff}")
    print(f"Student Users: {result}")
    print("-" * 30)

