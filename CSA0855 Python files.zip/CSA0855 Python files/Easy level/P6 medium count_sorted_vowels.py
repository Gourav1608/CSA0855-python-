def count_sorted_vowel_strings(n):
    if n <= 0:
        return 0  # Invalid input case
    
    dp = [1] * 5  # Initial state for n = 1
    
    for _ in range(2, n + 1):  # Build for lengths 2 to n
        for i in range(1, 5):
            dp[i] += dp[i - 1]  # Cumulative sum for lexicographical order
    
    return sum(dp)  # Total strings for length n

# Test cases
print(count_sorted_vowel_strings(1))  # Output: 5
print(count_sorted_vowel_strings(2))  # Output: 15
print(count_sorted_vowel_strings(33))  # Output: 66045
print(count_sorted_vowel_strings(-5))  # Output: 0 (invalid case)
print(count_sorted_vowel_strings(10))  # Output: 1001
