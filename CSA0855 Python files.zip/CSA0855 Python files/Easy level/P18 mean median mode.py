from statistics import mean, median, mode

def calculate_statistics(elements):
    # Calculate mean
    mean_value = mean(elements)
    # Calculate median
    median_value = median(elements)
    # Calculate mode (handle cases with no unique mode)
    try:
        mode_value = mode(elements)
    except:
        mode_value = "No unique mode"

    return mean_value, median_value, mode_value

# Test cases
test_cases = [
    [16, 18, 27, 16, 23, 21, 19],
    [26, 28, 37, 26, 33, 31, 29],
    [1.6, 1.8, 2.7, 1.6, 2.3, 2.1, 0.19],
    [0, 160, 180, 270, 160, 230, 210, 190, 0],
    [200, 180, 180, 270, 160, 270, 270, 190, 200],
    [100, 100, 100, 100, 100, 100, 100, 100, 100]
]

for i, elements in enumerate(test_cases, start=1):
    mean_value, median_value, mode_value = calculate_statistics(elements)
    print(f"Test Case {i}:")
    print(f"List of elements: {elements}")
    print(f"Mean = {mean_value}")
    print(f"Median = {median_value}")
    print(f"Mode = {mode_value}\n")
