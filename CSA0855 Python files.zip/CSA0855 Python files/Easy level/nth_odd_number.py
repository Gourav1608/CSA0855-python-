def nth_odd_number(n):
    if not isinstance(n, int):
        return "invalid value n must be an integer"
    if n < 0 :
        return "invalid input n should not be a negtive number"
    nth_odd = 4*n - 1
    return f"{n}th odd number after {n} odd number:{nth_odd}"

input_values = input("Enter a list of integers separated by commas (e.g., 5, 6, 7, 8): ")
try:
    # Convert input string into a list of integers
    test_cases = [int(x.strip()) for x in input_values.split(",")]
except ValueError:
    print("Invalid input: Please enter integers only.")
    test_cases = []

# Process each test case
for test in test_cases:
    print(f"Input: N = {test}")
    result = nth_odd_number(test)
    if isinstance(result, str):  # Check for error messages
        print(result)
    else:
        print(f"{test}th odd number after {test} odd numbers: {result}")
    print("-")
    
    
