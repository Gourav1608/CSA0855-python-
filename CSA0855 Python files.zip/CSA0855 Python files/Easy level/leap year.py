def is_leap_year(year):
    # Check if the year is divisible by 400
    if year % 400 == 0:
        return True
    # Check if the year is divisible by 100 but not 400
    elif year % 100 == 0:
        return False
    # Check if the year is divisible by 4 but not 100
    elif year % 4 == 0:
        return True
    # All other years are not leap years
    else:
        return False

# Get input from the user
year = int(input("Enter Year: "))

# Check if the year is a leap year and print the result
if is_leap_year(year):
    print(f"Given year {year} is a Leap Year")
else:
    print(f"Given year {year} is a Non Leap Year")
