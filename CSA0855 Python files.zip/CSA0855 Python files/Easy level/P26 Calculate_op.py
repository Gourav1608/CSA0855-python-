def calculate_pow(x, n):
    return x ** n

def calculate_add(x, n):
    return x + n

def calculate_sub(x, n):
    return x - n

def calculate_mul(x, n):
    return x * n

def calculate_div(x, n):
    if n == 0:
        return "Division by zero is not allowed"
    return x / n

def main():
    try:
        x = float(input("Enter the value of X: "))
        n = float(input("Enter the value of N: "))
        print("Choose an operation:")
        print("1: Pow(X, N)")
        print("2: Add(X, N)")
        print("3: Sub(X, N)")
        print("4: Mul(X, N)")
        print("5: Div(X, N)")
        choice = int(input("Choice: "))
        
        if choice == 1:
            result = calculate_pow(x, n)
            print(f"Pow({x}, {n}) = {result}")
        elif choice == 2:
            result = calculate_add(x, n)
            print(f"Add({x}, {n}) = {result}")
        elif choice == 3:
            result = calculate_sub(x, n)
            print(f"Sub({x}, {n}) = {result}")
        elif choice == 4:
            result = calculate_mul(x, n)
            print(f"Mul({x}, {n}) = {result}")
        elif choice == 5:
            result = calculate_div(x, n)
            print(f"Div({x}, {n}) = {result}")
        else:
            print("Invalid choice. Please select a number between 1 and 5.")
    except ValueError:
        print("Invalid input. Please enter numeric values for X and N, and a valid choice.")

# Run the main function
main()

# Test cases
test_cases = [
    (0, 4, 1),  # Pow(0, 4)
    (5, 0, 2),  # Add(5, 0)
    (-3, 3, 3), # Sub(-3, 3)
    (0, 0, 4),  # Mul(0, 0)
    (123, 123, 5) # Div(123, 123)
]

for x, n, choice in test_cases:
    print(f"\nTest case - X: {x}, N: {n}, Choice: {choice}")
    if choice == 1:
        result = calculate_pow(x, n)
        print(f"Pow({x}, {n}) = {result}")
    elif choice == 2:
        result = calculate_add(x, n)
        print(f"Add({x}, {n}) = {result}")
    elif choice == 3:
        result = calculate_sub(x, n)
        print(f"Sub({x}, {n}) = {result}")
    elif choice == 4:
        result = calculate_mul(x, n)
        print(f"Mul({x}, {n}) = {result}")
    elif choice == 5:
        result = calculate_div(x, n)
        print(f"Div({x}, {n}) = {result}")
    else:
        print("Invalid choice. Please select a number between 1 and 5.")
