def modify_string(s):
    # Calculate frequency of each character in the string
    frequency = {}
    for char in s:
        frequency[char] = frequency.get(char, 0) + 1
    
    # Modify the string
    result = []
    for char in s:
        freq = frequency[char]
        # Find the new character with circular distance
        new_char = chr(((ord(char) - ord('a') + freq) % 26) + ord('a'))
        result.append(new_char)
    
    # Return the modified string
    return ''.join(result)

# Test cases
print(modify_string("ghee"))       # Output: higg
print(modify_string("elephant"))   # Output: gnhgpbou
print(modify_string("apple"))      # Output: crrng
print(modify_string("orange"))     # Output: scbpig
print(modify_string("lion"))       # Output: nkom
