def calculate_square_and_cube(number):
    square = number ** 2
    cube = number ** 3
    return square, cube

# Test cases
test_cases = [0.6, 12, 0, -0.5, 14.25]

# Process and print results for each test case
for case in test_cases:
    square, cube = calculate_square_and_cube(case)
    print(f"Given Number: {case}")
    print(f"Square Number: {square}")
    print(f"Cube Number: {cube}")
    print("-" * 30)
