#To find the simple interest of different input using same function and using different rate of interest for senior citizen is 12% and for others 10% 

def calculate_simple_interest(principal, years, is_senior_citizen): #def defining a function , name of function depends on program, function as three parameters(input)
    if is_senior_citizen.lower() == 'y': # using if condition to get if a person is senior or not  
        rate_of_interest = 12 # assinging the rate of interet if yes 
    else:
        rate_of_interest = 10 # else 10 for others

    simple_interest = (principal * rate_of_interest * years) / 100 # simple interest using simpler method (P*Rate*y/100)
    return simple_interest #returning the value 

principal = float(input("Enter the principal amount: ")) # giving the input and using float to covert any string input into floating point numnber
years = float(input("Enter the no of years: "))
is_senior_citizen = input("Is customer senior citizen (y/n): ")

interest = calculate_simple_interest(principal, years, is_senior_citizen) # calling the calculate_simple_interest


print(f"Interest: {interest}") # printing the interest 
