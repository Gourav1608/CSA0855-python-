def print_pattern(rows):
    if rows <= 0 or not isinstance(rows, int):
        print("Invalid input. Please enter a positive integer.")
        return
    
    for i in range(1, rows + 1):
        # Print the numbers from i to 1 in each row
        for j in range(i, 0, -1):
            print(j, end=" ")
        print()  # Move to the next line after each row

# Get the input from the user
try:
    num_rows = float(input("Enter the number of rows: "))
    if num_rows.is_integer():  # Check if the input is a whole number
        num_rows = int(num_rows)
        print_pattern(num_rows)
    else:
        print("Invalid input. Please enter a whole number.")
except ValueError:
    print("Invalid input. Please enter a valid number.")
