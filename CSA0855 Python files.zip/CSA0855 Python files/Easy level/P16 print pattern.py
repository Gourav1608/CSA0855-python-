def print_pattern(rows):
    if rows <= 0 or not isinstance(rows, int):
        print("Invalid input! Please enter a positive integer.")
        return

    for i in range(1, rows + 1):
        for j in range(1, i + 1):
            print(f"0.{j}", end=" ")
        print()

# Test cases
test_cases = [4, 0, -1, 4.5, 6, 5]

# Process and print results for each test case
for case in test_cases:
    print(f"Input Rows: {case}")
    print_pattern(int(case) if isinstance(case, int) else case)
    print("-" * 30)
