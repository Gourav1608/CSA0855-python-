def add_matrices(mat1, mat2):
    # Check if both matrices have the same size
    if len(mat1) != len(mat2) or len(mat1[0]) != len(mat2[0]):
        print("Matrices are not the same size and cannot be added.")
        return
    
    # Create an empty matrix to store the result
    mat_sum = [[0 for _ in range(len(mat1[0]))] for _ in range(len(mat1))]
    
    # Perform element-wise addition
    for i in range(len(mat1)):
        for j in range(len(mat1[0])):
            mat_sum[i][j] = mat1[i][j] + mat2[i][j]
    
    return mat_sum

# Sample input matrices
mat1 = [[1, 2], [5, 3]]
mat2 = [[2, 3], [4, 1]]

# Add the matrices and print the result
result = add_matrices(mat1, mat2)
if result:
    print("Mat Sum =")
    for row in result:
        print(" ".join(map(str, row)))

# Test cases
mat1 = [[7, -1], [5, 4]]
mat2 = [[2, 5], [4, 3]]
result = add_matrices(mat1, mat2)
if result:
    print("\nTest Case 1:")
    for row in result:
        print(" ".join(map(str, row)))

mat1 = [[4, 8], [3, 7]]
mat2 = [[1, 0], [5, 2]]
result = add_matrices(mat1, mat2)
if result:
    print("\nTest Case 2:")
    for row in result:
        print(" ".join(map(str, row)))

mat1 = [[4, 8], [3, 7]]
mat2 = [[1, 0, 5], [2, 5, 6]]
result = add_matrices(mat1, mat2)  # This will display an error message because matrices are not the same size.

mat1 = [[3, -4], [8, 5]]
mat2 = [[9, -5], [6, -6]]
result = add_matrices(mat1, mat2)
if result:
    print("\nTest Case 4:")
    for row in result:
        print(" ".join(map(str, row)))

mat1 = [[0, 0]]
mat2 = [[0, 0, 0, 0]]
result = add_matrices(mat1, mat2)  # This will display an error message because matrices are not the same size.
