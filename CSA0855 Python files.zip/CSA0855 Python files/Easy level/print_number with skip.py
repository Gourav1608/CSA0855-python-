def print_numbers_with_skip(M, N, K):
    # Generate the sequence from M to N with step K
    if K == 0:
        print("K cannot be zero.")
        return
    
    # Check for the direction of iteration (forward or backward)
    if M <= N:
        result = list(range(M, N + 1, K + 1))
    else:
        result = list(range(M, N - 1, -(K + 1)))
    
    # Print the numbers, separated by commas
    print(", ".join(map(str, result)))

# Test cases
inputs = [
    [15, 5, 2],     # M = 15, N = 5, K = 2
    [25, 50, 4],    # M = 25, N = 50, K = 4
    [15, 100, -2],  # M = 15, N = 100, K = -2
    [0, 0, 2],      # M = 0, N = 0, K = 2
    [200, 200, 50]  
]

for test in inputs:
    print(f"Input: M = {test[0]}, N = {test[1]}, K = {test[2]}")
    print_numbers_with_skip(*test)
    print()

