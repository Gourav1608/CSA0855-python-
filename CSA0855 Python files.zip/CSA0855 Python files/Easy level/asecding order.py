# Python program to sort a list of names in alphabetical order
# based on user choice (Ascending or Descending)

def sort_names():
    print("Enter names one by one and type 'done' when finished:")
    names = []

    while True:
        name = input().strip()
        if name.lower() == 'done':
            break
        names.append(name)

    if not names:
        print("No names were entered.")
        return

    order = input("Order (A for Ascending / D for Descending): ").strip().upper()

    if order == 'A':
        sorted_names = sorted(names, key=str.casefold)
