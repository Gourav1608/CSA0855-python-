def count_vowels(InputString):
    # Define vowels
    vowels = "aeiouAEIOU"
    # Count the vowels in the string
    vowel_count = sum(1 for char in InputString if char in vowels)
    return vowel_count

# Sample input and output
test_cases = [
    "Saveetha School of Engineering",
    "India is my country",
    "All are my brothers and sisters",
    "Why dry sky",
    "Shy Try Cry EDUCATION"
]

# Process and print results for each test case
for case in test_cases:
    print(f"Input: {case}")
    print(f"Number of vowels = {count_vowels(case)}")
    print("-" * 30)
