from itertools import permutations

def find_combinations(input_digits):
    # Ensure input is valid (non-negative integer digits)
    if not input_digits.isdigit():
        return "Invalid input. Please enter non-negative integers only."
    
    # Generate permutations
    unique_digits = set(input_digits)  # Remove duplicates if necessary
    combos = [''.join(p) for p in permutations(unique_digits)]
    
    # Return or display results
    return '\n'.join(combos)

# Example usage
digits = input("Enter digits: ")
print(find_combinations(digits))
