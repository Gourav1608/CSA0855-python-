def remove_common_words(S1, S2):
    words1, words2 = set(S1.split()), set(S2.split())
    common = words1 & words2
    result1 = " ".join(word for word in S1.split() if word not in common)
    result2 = " ".join(word for word in S2.split() if word not in common)
    return result1, result2

# Test Cases
print(remove_common_words("sky is blue in color", "Raj likes sky blue color"))  
# Output: ("is in", "Raj likes")
