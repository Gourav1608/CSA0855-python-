def max_guests(T, E, L):
    if T <= 0 or len(E) != len(L):
        return "Invalid input"
    max_guests = current_guests = 0
    for enter, leave in zip(E, L):
        current_guests += enter - leave
        max_guests = max(max_guests, current_guests)
    return max_guests

# Test Cases
print(max_guests(5, [7, 0, 5, 1, 3], [1, 2, 1, 3, 4]))  # Output: 8
print(max_guests(-4, [1, 5, 9, 10], [0, 2, 3, 4]))      # Output: Invalid input
print(max_guests(4, [12, 85], [100]))                   # Output: Invalid input
