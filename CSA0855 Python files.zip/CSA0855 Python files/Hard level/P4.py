def get_season(month, day):
    month = month.lower()[:3]#The input month is converted to lowercase and truncated to its first three letters (e.g., "March" becomes "mar")
    if month == "mar" and day >= 20 or month in ("apr", "may") or (month == "jun" and day < 21):
        return "Summer"
    elif month == "jun" and day >= 21 or month in ("jul", "aug") or (month == "sep" and day < 22):
        return "Spring"
    elif month == "sep" and day >= 22 or month in ("oct", "nov") or (month == "dec" and day < 21):
        return "Fall"
    else:
        return "Winter"


print(get_season("March", 21))  
print(get_season("July", 29))   
