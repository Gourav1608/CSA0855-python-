from collections import Counter

def modify_string(S):
    freq = Counter(S)
    result = ""
    for char in S:
        shift = freq[char]
        new_char = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
        result += new_char
    return result

# Test Cases
print(modify_string("ghee"))        # Output: higg
print(modify_string("elephant"))    # Example output
print(modify_string("apple"))       # Example output
