#The function shuffle(l1, l2) alternately merges two lists l1 and l2. If the lists are of unequal lengths, the remaining elements of the longer list are appended at the end.
def shuffle(l1, l2):
    """
    This function takes two lists, l1 and l2, and combines their elements alternately.
    If one list is longer, its remaining elements are added to the end of the output.
    """
    result = []
    
    # Pair elements alternately using zip
    for a, b in zip(l1, l2):
        result.extend([a, b])
    
    # Append the remaining elements from the longer list len(l1) > len(l2):
    #If l1 is longer, there are extra elements in l1 beyond the length of l2.
    #l1[len(l2):]: Slices the extra elements in l1 starting from the index equal to the length of l2.
    #These extra elements are appended to the result list.
    #else:
    #If l2 is longer, the extra elements in l2 are sliced using l2[len(l1):] and appended to the result.
    if len(l1) > len(l2):
        result.extend(l1[len(l2):])
    else:
        result.extend(l2[len(l1):])
    
    return result

# Reading input and processing
def main():
    # Input for first list
    n1 = int(input("Enter the number of elements of l1: "))
    l1 = []
    for _ in range(n1):
        l1.append(int(input("Enter the element: ")))
    
    # Input for second list
    n2 = int(input("Enter the number of elements of l2: "))
    l2 = []
    for _ in range(n2):
        l2.append(int(input("Enter the element: ")))
    
    # Call the shuffle function
    shuffled_list = shuffle(l1, l2)
    print(f"Shuffled list = {shuffled_list}")

# Run the main function
if __name__ == "__main__":
    main()
