import re

def is_valid_number(s):
    """
    Check if the input string s is a valid number as per the given rules.
    """
    pattern = r'^[+-]?((\d+(\.\d*)?)|(\.\d+))([eE][+-]?\d+)?$'
    return bool(re.match(pattern, s.strip()))

# Test Cases
print(is_valid_number("0"))       # Output: True
print(is_valid_number("e"))       # Output: False
print(is_valid_number(" "))       # Output: False
print(is_valid_number("."))       # Output: False
print(is_valid_number("%"))       # Output: False
