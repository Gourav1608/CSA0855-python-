def reverse_words(s):
    return " ".join(s.split()[::-1])

# Test Cases
print(reverse_words("the sky is blue"))       # Output: "blue is sky the"
print(reverse_words(" hello world "))         # Output: "world hello"
